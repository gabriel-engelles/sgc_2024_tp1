<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'sgc_2024_tp1' );

/** Database username */
define( 'DB_USER', 'sgc_2024_tp1' );

/** Database password */
define( 'DB_PASSWORD', 'sgc_2024_tp1' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'mBa0)-66:n0sy7-Lw90wiK)`]OElct?m&q2W(z) ty0f2dwZrLXx=<;)#[~Jd[-e' );
define( 'SECURE_AUTH_KEY',  'Q-J2(%HodCDQ!!rMr[S3m|2A&R{F,CshK!,>8OGPQv}aG6#AFv{$${y-@j4zx8tC' );
define( 'LOGGED_IN_KEY',    'AsT<VL}U4^T5]@dNwl1s3?XGip%{8<}@7n(0&|;V22Lm;d5 <Nt~rs)|<U+6f2fT' );
define( 'NONCE_KEY',        '$WZ4x`aA~i:-?_0obxrO!hCZ2Covo_|>is(JL?wHyUJ:w$ dk$cO,.3f=;bW Q7?' );
define( 'AUTH_SALT',        '3Lo4aSdL-lHh-M]+Dt/Y jx}m!i4>r=clE%~{jQp:?&_#04=xU>wMP;Cy[9`,d[H' );
define( 'SECURE_AUTH_SALT', 'n)$NN(95mU*e$$t(b`}h~R}d+ WY(YKW]]p<BD%LHulM=%N2#i@}k({/glEgtNhv' );
define( 'LOGGED_IN_SALT',   '*rTf4D@xwwvYleczx52[FR/k^$bb>wFu}$FodX4j/[1FUOz.Gwl$:EpNC8A>gDUp' );
define( 'NONCE_SALT',       'p?A~9UVPoAe*Q^w%rpn$gr|wlXJS5 RQZ[nrVL!3B*KVcTxKUkZ0pHT{b&HP/]aI' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
